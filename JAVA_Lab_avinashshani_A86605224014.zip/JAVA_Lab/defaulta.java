class defaulta{
    int value = 20;

    void show() {
        System.out.println("Default access");
    }
}