// Student class
class Student {

    int id;
    String name;

    // Constructor
    Student(int i, String n) {
        id = i;
        name = n;
    }
}

// Main class
public class student {

    // Method to display student details
    static void display(Student s) {
        System.out.println("Student ID: " + s.id);
        System.out.println("Student Name: " + s.name);
    }

    public static void main(String[] args) {

        // Creating Student object
        Student s1 = new Student(101, "Rahul");

        // Passing object to method
        display(s1);
    }
}