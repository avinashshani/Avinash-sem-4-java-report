import java.util.Scanner;

public class TransposeMatrix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] a = new int[2][3];
        int[][] t = new int[3][2];

        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 3; j++)
                a[i][j] = sc.nextInt();

        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 3; j++)
                t[j][i] = a[i][j];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 2; j++) System.out.print(t[i][j] + " ");
            System.out.println();
        }
        sc.close();
    }
}