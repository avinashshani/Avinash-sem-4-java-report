class private1 {
    private int number = 10;

    private void display() {
        System.out.println("Private method");
    }

    public static void main(String[] args) {
        private1 obj = new private1();
        System.out.println(obj.number);
        obj.display();
    }
}