import java.util.StringTokenizer;

public class TokenizerDemo {
    public static void main(String[] args) {
        String sentence = "Java is a powerful language";
        StringTokenizer st = new StringTokenizer(sentence);

        System.out.println("Total words = " + st.countTokens());

        while (st.hasMoreTokens()) {
            String word = st.nextToken();
            System.out.println(word + " - " + word.length());
        }
    }
}