class Book {

    String title;
    String author;

    Book(String t, String a) {
        title = t;
        author = a;
    }
}

public class Main11 {

    static void display(Book b) {

        System.out.println("Book Title: " + b.title);
        System.out.println("Author Name: " + b.author);
    }

    public static void main(String[] args) {

        Book b1 = new Book("Java Programming", "James Gosling");

        display(b1);
    }
}