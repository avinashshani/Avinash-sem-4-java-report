class PrivateExample {

    private int number = 10;

    private void display() {
        System.out.println("Private method");
    }

    public static void main(String[] args) {

        PrivateExample obj = new PrivateExample();

        System.out.println(obj.number);
        obj.display();
    }
}