class Bank {

    double rate() {
        return 0;
    }
}

class SBI extends Bank {

    double rate() {
        return 6.5;
    }
}

class HDFC extends Bank {

    double rate() {
        return 7.2;
    }
}

class ICICI extends Bank {

    double rate() {
        return 6.8;
    }
}

public class bank {

    public static void main(String[] args) {

        SBI s = new SBI();
        HDFC h = new HDFC();
        ICICI i = new ICICI();

        System.out.println("SBI Rate = " + s.rate() + "%");
        System.out.println("HDFC Rate = " + h.rate() + "%");
        System.out.println("ICICI Rate = " + i.rate() + "%");
    }
}