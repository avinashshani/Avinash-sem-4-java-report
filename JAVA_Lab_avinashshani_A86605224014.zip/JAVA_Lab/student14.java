class BankAccount {

    int accountNumber;
    double balance;

    BankAccount(int a, double b) {
        accountNumber = a;
        balance = b;
    }
}

public class student14 {

    static BankAccount getAccount() {

        BankAccount acc = new BankAccount(12345, 50000);
        return acc;
    }

    public static void main(String[] args) {

        BankAccount b1 = getAccount();

        System.out.println("Account Number: " + b1.accountNumber);
        System.out.println("Balance: " + b1.balance);
    }
}