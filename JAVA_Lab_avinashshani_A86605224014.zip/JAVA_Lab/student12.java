class Student {

    int id;
    String name;

    Student(int i, String n) {
        id = i;
        name = n;
    }
}

public class student12 {

    static void display(Student s) {
        System.out.println("Student ID: " + s.id);
        System.out.println("Student Name: " + s.name);
    }

    public static void main(String[] args) {

        Student s1 = new Student(101, "Rahul");

        display(s1);
    }
}