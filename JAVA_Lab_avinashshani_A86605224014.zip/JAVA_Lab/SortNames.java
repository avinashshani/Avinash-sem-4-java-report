import java.util.ArrayList;
import java.util.Collections;

public class SortNames {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();
        names.add("Zara");
        names.add("Aman");
        names.add("Ravi");
        names.add("Mona");

        Collections.sort(names);

        for (String s : names) System.out.println(s);
    }
}