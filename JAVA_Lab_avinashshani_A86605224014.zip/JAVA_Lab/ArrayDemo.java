import java.util.Scanner;

public class ArrayDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            arr[i] = sc.nextInt();
        }

        int sum = 0;
        int largest = arr[0];
        int smallest = arr[0];

        System.out.println("All elements:");
        for (int i = 0; i < 10; i++) {
            System.out.print(arr[i] + " ");
            sum += arr[i];

            if (arr[i] > largest) {
                largest = arr[i];
            }
            if (arr[i] < smallest) {
                smallest = arr[i];
            }
        }

        System.out.println();
        System.out.println("Sum of elements = " + sum);
        System.out.println("Largest number = " + largest);
        System.out.println("Smallest number = " + smallest);

        sc.close();
    }
}