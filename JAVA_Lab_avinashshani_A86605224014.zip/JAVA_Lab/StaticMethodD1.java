public class StaticMethodD1 {

    
    static int count = 0;

    
    public static void displayMessage() {
        System.out.println("Hello! This is a static method.");
    }

    
    public static int addNumbers(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        
        StaticMethodD1.displayMessage();

        
        int sum = StaticMethodD1.addNumbers(10, 20);
        System.out.println("Sum: " + sum);

        
        System.out.println("Initial count: " + StaticMethodD1.count);

        
        StaticMethodD1.count++;
        System.out.println("Updated count: " + StaticMethodD1.count);
    }
}