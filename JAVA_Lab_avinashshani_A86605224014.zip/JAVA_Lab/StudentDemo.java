class Student {
    String name;
    int age;

    Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

public class StudentDemo {
    static Student createStudent() {
        return new Student("Alice", 20);
    }

    public static void main(String[] args) {
        Student s = createStudent();
        s.display();
    }
}
