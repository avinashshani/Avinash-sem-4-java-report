class accessp {

    private int number = 10;

    private void display() {
        System.out.println("Private method");
    }

    public static void main(String[] args) {

        accessp obj = new accessp();

        System.out.println(obj.number);
        obj.display();
    }
}