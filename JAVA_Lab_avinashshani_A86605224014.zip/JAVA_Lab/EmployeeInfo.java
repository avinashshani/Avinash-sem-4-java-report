class Employee {
    int empId;
    String name;
    double salary;

    Employee(int empId, String name, double salary) {
        this.empId = empId;
        this.name = name;
        this.salary = salary;
    }
}

public class EmployeeInfo {
    static void showEmployee(Employee e) {
        System.out.println("ID: " + e.empId + ", Name: " + e.name + ", Salary: " + e.salary);
    }

    public static void main(String[] args) {
        Employee e1 = new Employee(201, "Bob", 50000);
        showEmployee(e1);
    }
}
