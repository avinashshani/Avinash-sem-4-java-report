class BankAccount {
    int accountNumber;
    double balance;

    BankAccount(int accNo, double bal) {
        accountNumber = accNo;
        balance = bal;
    }

    void display() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
}

public class Main13 {

    static BankAccount createAccount() {
        BankAccount b = new BankAccount(12345, 50000.75);
        return b;
    }
        public static void main(String[] args) {

        BankAccount acc = createAccount();

        // Displaying details
        acc.display();
    }
}