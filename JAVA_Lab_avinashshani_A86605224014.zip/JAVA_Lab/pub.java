public class pub {

    public void show() {
        System.out.println("Public method");
    }

    public static void main(String[] args) {

        pub obj = new pub();

        obj.show();
    }
}