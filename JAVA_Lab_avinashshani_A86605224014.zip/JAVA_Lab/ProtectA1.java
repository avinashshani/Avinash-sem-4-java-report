class ProtectA1 {

    protected void display() {
        System.out.println("Protected method");
    }

    public static void main(String[] args) {

        ProtectA1 obj = new ProtectA1();

        obj.display();
    }
}