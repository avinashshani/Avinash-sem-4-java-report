class Person {
    String name;
    int age;

    void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

class Student extends Person {
    int id;

    void show() {
        System.out.println("ID: " + id);
    }

    public static void main(String[] args) {
        Student s = new Student();
        s.name = "Rahul";
        s.age = 20;
        s.id = 101;
        s.display();
        s.show();
    }
}