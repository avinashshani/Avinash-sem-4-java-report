class Student {

    int id;
    String name;

    Student(int i, String n) {
        id = i;
        name = n;
    }
}

public class Student13 {

    static Student getStudent() {

        Student s = new Student(101, "Rahul");
        return s;
    }

    public static void main(String[] args) {

    Student s1 = getStudent();

    System.out.println("Student ID: " + s1.id);
    System.out.println("Student Name: " + s1.name);
    }
}