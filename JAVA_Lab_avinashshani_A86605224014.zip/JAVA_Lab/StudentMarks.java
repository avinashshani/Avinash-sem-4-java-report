import java.util.Scanner;

public class StudentMarks {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] marks = new int[5];

        System.out.println("Enter marks of 5 students:");
        for (int i = 0; i < 5; i++) {
            marks[i] = sc.nextInt();
        }

        int sum = 0;
        int highest = marks[0];

        for (int i = 0; i < 5; i++) {
            sum += marks[i];
            if (marks[i] > highest) {
                highest = marks[i];
            }
        }

        double average = sum / 5.0;
        int aboveAverageCount = 0;

        for (int i = 0; i < 5; i++) {
            if (marks[i] > average) {
                aboveAverageCount++;
            }
        }

        System.out.println("Average marks = " + average);
        System.out.println("Highest marks = " + highest);
        System.out.println("Number of students scoring above average = " + aboveAverageCount);

        sc.close();
    }
}