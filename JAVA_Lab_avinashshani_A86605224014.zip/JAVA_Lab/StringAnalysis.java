public class StringAnalysis {
    public static void main(String[] args) {
        String s = "Hello World";
        int vowels = 0, consonants = 0;

        for (int i = 0; i < s.length(); i++) {
            char ch = Character.toLowerCase(s.charAt(i));
            if (ch >= 'a' && ch <= 'z') {
                if ("aeiou".indexOf(ch) >= 0) vowels++;
                else consonants++;
            }
        }

        String rev = "";
        for (int i = s.length() - 1; i >= 0; i--) rev += s.charAt(i);

        System.out.println("Vowels = " + vowels);
        System.out.println("Consonants = " + consonants);
        System.out.println("Reverse = " + rev);
    }
}