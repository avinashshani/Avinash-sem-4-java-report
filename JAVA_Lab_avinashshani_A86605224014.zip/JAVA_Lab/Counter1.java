public class Counter1 {
    static int count; 

    static void showCount() {
        System.out.println("Total: " + count);
    }
        public static void main(String[] args) {
        Counter1.count = 100;
        Counter1.showCount(); 
    }
    
}

