class defaultA1 {

    int value = 20;

    void show() {
        System.out.println("Default access");
    }

    public static void main(String[] args) {

        defaultA1 obj = new defaultA1();

        System.out.println(obj.value);
        obj.show();
    }
}