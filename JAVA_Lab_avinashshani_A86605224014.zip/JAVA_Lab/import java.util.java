import java.util.ArrayList;
import java.util.LinkedHashSet;

public class RemoveDuplicates {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 1; i <= 10; i++) list.add(i % 5);

        LinkedHashSet<Integer> set = new LinkedHashSet<>(list);
        ArrayList<Integer> finalList = new ArrayList<>(set);

        System.out.println(finalList);
    }
}