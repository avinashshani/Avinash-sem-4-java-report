// Example of static method in Java
public class StaticMethodDemo {

    // Static variable
    static int count = 0;

    // Static method
    public static void displayMessage() {
        System.out.println("Hello! This is a static method.");
    }

    // Static method with parameters
    public static int addNumbers(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        // Calling static method without creating an object
        StaticMethodDemo.displayMessage();

        // Calling static method with parameters
        int sum = StaticMethodDemo.addNumbers(10, 20);
        System.out.println("Sum: " + sum);

        // Accessing static variable
        System.out.println("Initial count: " + StaticMethodDemo.count);

        // Updating static variable
        StaticMethodDemo.count++;
        System.out.println("Updated count: " + StaticMethodDemo.count);
    }
}