class Employee {

    int empId;
    String name;
    double salary;

 
    Employee(int id, String n, double s) {
        empId = id;
        name = n;
        salary = s;
    }
}

public class employee11 {

    static void display(Employee e) {

        System.out.println("Employee ID: " + e.empId);
        System.out.println("Employee Name: " + e.name);
        System.out.println("Employee Salary: " + e.salary);
    }

    public static void main(String[] args) {

        Employee e1 = new Employee(101, "Rahul", 50000);

        display(e1);
    }
}