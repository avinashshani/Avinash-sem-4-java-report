class Vehicle {

    void start() {
        System.out.println("Vehicle is starting");
    }
}

class Car extends Vehicle {

    void start() {
        System.out.println("Car starts with key");
    }
}

class Bike extends Vehicle {

    void start() {
        System.out.println("Bike starts with button");
    }
}

public class vehicles {

    public static void main(String[] args) {

        Car c = new Car();
        Bike b = new Bike();

        c.start();
        b.start();
    }
}