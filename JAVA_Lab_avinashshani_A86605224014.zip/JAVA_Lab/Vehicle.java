// Parent class
class Vehicle {

    void start() {
        System.out.println("Vehicle is starting");
    }
}

// Child class Car
class Car extends Vehicle {

    void start() {
        System.out.println("Car starts with key");
    }
}

// Child class Bike
class Bike extends Vehicle {

    void start() {
        System.out.println("Bike starts with button");
    }
}

// Main class
public class Main {

    public static void main(String[] args) {

        Car c = new Car();
        Bike b = new Bike();

        c.start();
        b.start();
    }
}