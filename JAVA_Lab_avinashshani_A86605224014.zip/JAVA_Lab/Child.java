class Parent {

    protected int number = 50;

    protected void display() {
        System.out.println("Protected method Parent class");
    }
}

class Child extends Parent {

    void show() {
        System.out.println("Protected variable: " + number);
        display();
    }

    public static void main(String[] args) {

        Child obj = new Child();
        obj.show();
    }
}