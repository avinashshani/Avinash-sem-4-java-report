public class MergeArrays {
    public static void main(String[] args) {
        int[] arr1 = {10, 20, 30, 40};
        int[] arr2 = {50, 60, 70, 80};

        int len1 = arr1.length;
        int len2 = arr2.length;

        int[] merged = new int[len1 + len2];

        for (int i = 0; i < len1; i++) {
            merged[i] = arr1[i];
        }

        for (int i = 0; i < len2; i++) {
            merged[len1 + i] = arr2[i];
        }

        System.out.println("Merged array:");
        for (int i = 0; i < merged.length; i++) {
            System.out.print(merged[i] + " ");
        }
    }
}