class Student {
    int id;
    String name;

    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }
}

public class Studentinfo {
    static void displayStudent(Student s) {
        System.out.println("ID: " + s.id + ", Name: " + s.name);
    }

    public static void main(String[] args) {
        Student s1 = new Student(101, "Alice");
        displayStudent(s1);
    }
}
